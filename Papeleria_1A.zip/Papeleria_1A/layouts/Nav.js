const Nav=()=>{

    const vista=
    `
    <nav class="navbar navbar-expand-lg bg-light navbar-menu-end">
      <div class="container-fluid">
            <a class="navbar-brand" href="#/">
              <img src="/Papeleria_1A/assets/img/Logo final.ico" alt="Bootstrap" width="120" height="114"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <h5>
            <div class="collapse navbar-collapse" id="navbarSupportedContent"></div>
            <ul class="navbar-nav me-auto  mb-lg-3 ">
              <li class="nav-item">
              <a class="nav-link " aria-current="page" href="#/comprarproductos/">Mis Productos<i class="bi bi-cart3"></i></a>
              </li>
              <li class="nav-item">
            <a class="nav-link" aria-current="page" href="#/registrarse/">Registrarse</a>
            </li> 
            <div class="collapse navbar-collapse" id="navbarSupportedContent"></div>
            <li class="nav-item">
            <a class="nav-link" aria-current="page" href="#/productosfavoritos/"><i class="bi bi-star-fill"></i>Favoritos</a>
            </li> 
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-person-circle"></i>Mi Perfil
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#/iniciarsesion/">Iniciar Sesión</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="#">Cerrar Sesión</a></li>
              </ul>
            </li>
            </ul>

            <div class="collapse navbar-collapse" id="navbarSupportedContent"></div>
              <div class="btn-group">
                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Inicio
                </button>
              </div>
              
              <div class="btn-group">
                <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                  Productos
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                  <li><a class="dropdown-item" href="#">Cuadernos</a></li>
                  <li><a class="dropdown-item" href="#">Colores</a></li>
                  <li><a class="dropdown-item" href="#">Varios</a></li>
                </ul>
              </div>
              
              <div class="btn-group">
                <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
                  Crear Producto
                </button>
                <ul class="dropdown-menu dropdown-menu-lg-end">
                  <li><a class="dropdown-item" href="#/crearproducto/">Nombre</a></li>
                  <li><a class="dropdown-item" href="#">Referencia</a></li>
                  <li><a class="dropdown-item" href="#">Precio</a></li>
                </ul>
              </div>
              
              <div class="btn-group">
                <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
                  Categoria
                </button>
                <ul class="dropdown-menu  dropdown-menu-lg-start">
                  <li><a class="dropdown-item" href="#">Escolares</a></li>
                  <li><a class="dropdown-item" href="#">Oficina</a></li>
                  <li><a class="dropdown-item" href="#">Archivo</a></li>
                </ul>
              </div>

              <div class="btn-group">
                <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false">
                  iD Categoria
                </button>
                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-lg-start">
                  <li><a class="dropdown-item" href="#">id</a></li>
                  <li><a class="dropdown-item" href="#">id 2</a></li>
                  <li><a class="dropdown-item" href="#">id 3</a></li>
                </ul>
              </div>
             
       </h5>            
        </div>
      </div>
    </nav>
    `
    return vista

}

export {Nav}