const Footer= ()=>{
const vista=
`
<footer class="text-center text-lg-start bg-light text-muted">
    <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
        <div class="me-5 d-none d-lg-block">
    </section>
    <section class="">
      <div class="container text-center text-md-start mt-5">
        <div class="row mt-3">
          <div class="col-md-4 col-lg-2 col-xl-2 mx-auto mb-3">
            <h6 class="text-uppercase fw-bold mb-4"style="background-color:azure;"></style=>
                Conéctate con nosotros a travez de nuestras redes sociales:
            </h6>
             <div>
                  <a href="" class="me-4 text-reset"><i class="bi bi-facebook"></i></a>
                  <a href="" class="me-4 text-reset"><i class="fbi bi-instagram"></i></a>
                  <a href="" class="me-4 text-reset"><i class="fbi bi-youtube"></i></a>
                  <a href="" class="me-4 text-reset"><i class="bi bi-google"></i></a>
             </div>
         </div>
  
          <div class="col-md-4 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold mb-4" style="background-color:azure;">
              Productos
            </h6>
            <p>
              <a href="#" class="text-reset">Ofertas del Mes</a>
            </p>
            <p>
              <a href="#" class="text-reset">Más Vendidos</a>
            </p>
            <p>
              <a href="#" class="text-reset">Mis Deseos</a>
            </p>
            <p>
              <a href="#" class="text-reset">Nuevos</a>
            </p>
          </div>
  
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-4">
            <h6 class="text-uppercase fw-bold mb-4" style="background-color:azure;">
              links
            </h6>
            <p>
              <a href="/" class="text-reset">Acerca de nosotros</a>
            </p>
            <p>
              <a href="/" class="text-reset">Politicas de Privacidad</a>
            </p>
            <p>
              <a href="/" class="text-reset">Terminos y Condiciones</a>
            </p>
            <p>
              <a href="/" class="text-reset">Ayuda</a>
            </p>
          </div>
  
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <h6 class="text-uppercase fw-bold mb-4" style="background-color:azure;">Contáctanos</h6>
            <p><i class="fas fa-home me-3"></i>Av. 50 #23-65, Bga, Stder.</p>
            <p>
              <i class="fas fa-envelope me-3"></i>
                contacto@papeleriaunoa.com
                </p>
                <p><i class="fas fa-phone me-3"></i> + 57 334 567 88</p>
                <p><i class="fas fa-print me-3"></i> + 57 334 567 89</p>
            </div>
            </div>
         </section>
  
        <div class="text-center p-4" style="background-color:rgb(182, 235, 241);">
            © 2022 Copyright:
            <a class="text-reset fw-bold" href="https://mdbootstrap.com/">Room 4</a>
        </div>
    </footer>
`

return vista


}

export {Footer}