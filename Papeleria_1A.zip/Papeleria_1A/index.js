console.log("Corriendo...")

import {App} from "./routers/App.js"

window.addEventListener("load", App)
window.addEventListener("hashchange", App)
