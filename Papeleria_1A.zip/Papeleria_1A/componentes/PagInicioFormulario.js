const PagInicioFormulario= ()=>{
    const vista=
    `
 
    `
    retunr vista
}

export {PagInicioFormulario}