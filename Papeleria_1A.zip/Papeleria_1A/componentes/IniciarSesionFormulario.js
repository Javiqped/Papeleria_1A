
const IniciarSesionFormulario=()=>{
    const vista=
  
    `
    <form>
      <div class="form-floating mb-3">
        <input type="text" class="form-control" id="nombre usuario" placeholder="nombre usuario">
        <label for="floatingPassword"><i class="bi bi-person-fill"></i>Nombre Usuario</label>
      </div>
      <div class="form-floating mb-3">
        <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
        <label for="floatingPassword"><i class="bi bi-lock-fill"></i>Contraseña</label>
      </div>
    <fieldset class="row mb-3">
      <div class="form-floating ">
        <a href="">¿Olvidaste tu contraseña? </a>
        </div>
    </fieldset>
    <div class="row mb-3">
      <div class="col-sm-10 offset-sm-2">
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
    <a class="navbar-brand" href="/"><img src="/Papeleria_1A/assets/img/FACEB.png" alt="Bootstrap" width="50" height="50"></a>
    <a class="navbar-brand" href="/"><img src="/Papeleria_1A/assets/img/google.png" alt="Bootstrap" width="50" height="50"></a>


  </form> 

    `

    return vista
}

export {IniciarSesionFormulario}