const DetalleProductoFormulario=()=>{
    const vista=
    `

    `
    return vista

}

export {DetalleProductoFormulario}