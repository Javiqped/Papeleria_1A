

const RegistrarseFormulario= ()=>{
    const vista=
    `
    <form>
      <div class="form-floating mb-3">
        <input type="text" class="form-control" id="nombre" placeholder="nombre">
        <label for="floatingInput">Nombre</label>
      </div>
      <div class="form-floating mb-3">
        <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
        <label for="floatingInput">Email</label>
      </div>
      <div class="form-floating mb-3">
        <input type="text" class="form-control" id="nombre usuario" placeholder="nombre usuario">
        <label for="floatingPassword"><i class="bi bi-person-fill"></i>Nombre Usuario</label>
      </div>
      <div class="form-floating mb-3">
        <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
        <label for="floatingPassword"><i class="bi bi-lock-fill"></i>Contraseña</label>
      </div>
    <fieldset class="row mb-3">
      <div class="form-floating ">
        <select class="form-select" aria-label="Default select example">
          <option selected>Seleccionar Tipo Usuario</option>
          <option value="1">Administrador</option>
          <option value="2">Empleado</option>
          <option value="3">Cliente</option>
          <option value="3">Proveedor</option>
        </select>
        </div>
    </fieldset>
    <div class="row mb-3">
      <div class="col-sm-10 offset-sm-2">
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Registrarse</button>
    <a class="navbar-brand" href="/"><img src="/Papeleria_1A/assets/img/FACEB.png" alt="Bootstrap" width="50" height="50"></a>
    <a class="navbar-brand" href="/"><img src="/Papeleria_1A/assets/img/google.png" alt="Bootstrap" width="50" height="50"></a>
  </form>    
    
  `

  return vista
}

export {RegistrarseFormulario}