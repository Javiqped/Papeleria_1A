const CrearProductoFormulario=()=>{
    const vista=
    `

    `
    return vista

}

export {CrearProductoFormulario}