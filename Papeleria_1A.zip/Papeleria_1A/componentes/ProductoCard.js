const ProductoCard=()=>{
    const vista=
    `
    <div class="row row-cols-1 row-cols-md-2 g-4">
        <div class="col">
          <div class="card">
            <img src="/Papeleria_1A/assets/img/cuaderno argollado.jpg" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">CUADERNO ARGOLLADO MUJER $10.000</h5>
                <a href="#/comprar/" class="btn btn-primary">COMPRAR</a>
              <a href="#/productosfavoritos/" class="btn btn-primary">FAVORITOS</a>
            </div>
          </div>
        </div>

        <div class="col">
            <div class="card">
              <img src="/Papeleria_1A/assets/img/arg hombre.jpg" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">CUADERNO ARGOLLADO HOMBRE $10.000</h5>
                <a href="#" class="btn btn-primary">COMPRAR</a>
                <a href="#" class="btn btn-primary">FAVORITOS</a>
              </div>
            </div>
          </div>


          <div class="col">
            <div class="card">
              <img src="/Papeleria_1A/assets/img/cuaderno-cosidoo.png" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">CUADERNO 100 HOJAS NIÑA $6.000</h5>
                <a href="#" class="btn btn-primary">COMPRAR</a>
                <a href="#" class="btn btn-primary">FAVORITOS</a>
              </div>
            </div>
          </div>

          <div class="col">
            <div class="card">
              <img src="/Papeleria_1A/assets/img/cuaderno niño.jpg" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">CUADERNO 100 HOJAS NIÑO $6.000</h5>
                <a href="#" class="btn btn-primary">COMPRAR</a>
                <a href="#" class="btn btn-primary">FAVORITOS</a>
              </div>
            </div>
          </div>
 `
    return vista
}

export {ProductoCard}