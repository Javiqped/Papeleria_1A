import { Nav } from "../layouts/Nav.js"
import { Footer } from "../layouts/Footer.js"
import { ProductosCreados } from "../pages/ProductosCreados.js"
import { Registrarse } from "../pages/Registrarse.js"
import { Error404 } from "../pages/Error404.js"
import resolverRuta from "../connections/helpers/resolverRuta.js"
import getHash from "../connections/helpers/getHash.js"
import { IniciarSesion } from "../pages/IniciarSesion.js"
import { ComprarProducto } from "../pages/ComprarProducto.js"
import { CrearProducto } from "../pages/CrearProducto.js"
import { DetalleProducto } from "../pages/DetalleProducto.js"



const Rutas={
    "/":ProductosCreados,
    "/registrarse": Registrarse,
    "/iniciarsesion": IniciarSesion,
    "/comprarproductos": ComprarProducto,
    "/crearproducto": CrearProducto,
    "/detalleproducto": DetalleProducto,
}


const App= async ()=>{

    const header=document.querySelector("header")
    const main=document.querySelector("main")
    const footer=document.querySelector("footer")
  
    header.innerHTML= await Nav()
    footer.innerHTML= Footer()

    let ruta= await resolverRuta(getHash())

    let pagina= (Rutas[ruta]) ? Rutas[ruta]: Error404

    main.innerHTML= await pagina()

  
}

export {App}