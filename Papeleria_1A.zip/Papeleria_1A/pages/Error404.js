
const Error404= ()=>{

const vista=

`
<div class="fs-1 fw-bold"><h2>Error 404</h2></div>
`
return vista

}

export {Error404}