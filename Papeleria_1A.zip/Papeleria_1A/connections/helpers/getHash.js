export default ()=> location.hash.slice(1).split("/")[1] || "/"


//#/Registrarse/
